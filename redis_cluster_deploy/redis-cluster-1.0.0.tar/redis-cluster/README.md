# Redis Helm Chart

## Questions:

    1. Create a Helm chart from Scratch to deploy Redis
        a. We should be able to deploy a clustered Redis
        b. The cluster size can be from 1 node to 10+ nodes
        c. Data in Redis should be Replicated and persisted
        d. Please test to make sure that Redis Cluster has formed.

## Expected Outputs:

    1. Redis Helm chart in proper format
        a. Once the cluster is created, all we will be doing is helm install/upgrade
        b. If you have any prerequisites, please mention them

## Solution:

## Overview

This Helm chart deploys a Redis cluster on Kubernetes using StatefulSets. The chart supports creating a Redis cluster with persistent storage, and configuration options for clustering and replication.

## Features

- Deploys a Redis cluster with configurable number of replicas.
- Configures Redis with clustering enabled.
- Uses StatefulSets for stable network identities and persistent storage.
- Provides customizable Redis configuration through a ConfigMap.

## Prerequisites

- Kubernetes cluster (version >= 1.14)
- Helm (version >= 3.x)
- Persistent storage class configured in your Kubernetes cluster

## Quick Start

### Add Helm Repository

Add the repository containing the Redis Helm chart:

```bash
helm repo add my-repo https://my-repo-url
helm repo update
```
### Install Redis Chart

```bash
helm install my-redis my-repo/redis-cluster
```

### Custom Values
To customize the installation, you can provide your own values.yaml file:

```bash
helm install my-redis my-repo/redis-cluster -f values.yaml
```

### Uninstall Redis Chart
To remove the Redis deployment:

```bash
helm uninstall my-redis
```

### Testing

Run time snapshots have been attached
