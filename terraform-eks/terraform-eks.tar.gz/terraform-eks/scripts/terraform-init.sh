#!/bin/bash
terraform init
