#!/bin/bash

Proj_dir="/root/poc/terraform-eks"
# Check if environment parameter is provided
if [ -z "$1" ]; then
  echo "Usage: $0 <environment>"
  exit 1
fi

ENVIRONMENT=$1

cd $Proj_dir/environments/$ENVIRONMENT

terraform plan -var-file=terraform.tfvars
