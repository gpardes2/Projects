# terraform-eks

## Description
This project sets up an Amazon EKS (Elastic Kubernetes Service) cluster using Terraform. It includes modules for IAM, VPC, security, and EKS itself, and supports multiple environments (dev, staging, prod).

## Prerequisites
- Terraform v1.0 or later
- AWS CLI configured with appropriate credentials
- kubectl installed

## Installation
1. Clone the repository:
    ```sh
    git clone <repository-url>
    cd terraform-eks
    ```
2. Initialize Terraform:
    ```sh
    terraform init
    ```

## Usage
1. To plan the infrastructure changes:
    ```sh
    ./scripts/terraform-plan.sh <environment>
    ```
2. To apply the changes:
    ```sh
    ./scripts/terraform-apply.sh <environment>
    ```
3. To destroy the infrastructure:
    ```sh
    ./scripts/terraform-destroy.sh <environment>
    ```

## Directory Structure
- `main.tf`: Main Terraform configuration file.
- `variables.tf`: Variables used in the Terraform configuration.
- `outputs.tf`: Outputs of the Terraform configuration.
- `scripts/`: Shell scripts to manage Terraform operations.
- `modules/`: Contains reusable Terraform modules.
  - `iam/`: IAM module.
  - `vpc/`: VPC module.
  - `security/`: Security module.
  - `eks/`: EKS module.
- `environments/`: Contains environment-specific configurations.
  - `dev/`: Development environment.
  - `staging/`: Staging environment.
  - `prod/`: Production environment.

## Scripts
- `terraform-init.sh`: Initializes Terraform.
- `terraform-plan.sh`: Generates and shows the execution plan.
- `terraform-apply.sh`: Applies the changes required to reach the desired state.
- `terraform-destroy.sh`: Destroys the Terraform-managed infrastructure.

## Modules
- **IAM**: Manages IAM roles and policies.
- **VPC**: Sets up the Virtual Private Cloud.
- **Security**: Configures security groups and other security-related resources.
- **EKS**: Provisions the EKS cluster.

## Environments
- **dev**: Development environment configuration.
- **staging**: Staging environment configuration.
- **prod**: Production environment configuration.

## Outputs
The project generates various outputs such as the EKS cluster endpoint, security group IDs, and VPC IDs.

